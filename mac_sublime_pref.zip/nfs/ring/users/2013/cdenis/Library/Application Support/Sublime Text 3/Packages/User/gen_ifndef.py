# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    gen_ifndef.py                                      :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: cdenis <cdenis@student.42.fr>              +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2013/08/27 20:40:37 by cdenis            #+#    #+#              #
#    Updated: 2013/08/27 21:38:32 by cdenis           ###   ########.fr        #
#                                                                              #
# **************************************************************************** #
import sublime, sublime_plugin, os

class DefineHeaderCommand(sublime_plugin.TextCommand):
	def run(self, edit):
		f_name = os.path.basename(self.view.file_name()).upper().replace('.', '_')
		ifndef =  "#ifndef " + f_name + "\n"
		ifndef += "# define " + f_name + "\n\n"
		ifndef += "#endif /* " + f_name + "*/\n"
		self.view.insert(edit, 892, ifndef)
