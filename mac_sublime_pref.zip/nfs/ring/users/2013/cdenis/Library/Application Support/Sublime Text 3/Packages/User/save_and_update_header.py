import sublime, sublime_plugin

class SaveAndUpdateHeaderCommand(sublime_plugin.TextCommand):
	def run(self):
		self.view.run_command("prompt_header")
		self.view.run_command("save")
