/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_eval.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cdenis <cdenis@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/08/30 02:00:13 by cdenis            #+#    #+#             */
/*   Updated: 2013/08/30 03:17:01 by cdenis           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "eval_expr.h"

int		ft_next_nbr(char *str)
{
	int		in_braket;
	int		i;

	i = 0;
	in_braket = 0;
	while (str[i])
	{
		write(1, &str[i], 1);
		if (in_braket)
		{
			if (str[i] == '(')
				in_braket++;
			else if (str[i] == ')')
			{
				in_braket--;
				if (!in_braket)
					break ;
			}
		}
		else if (str[i + 1] < '0')
			return (i + 1);
		i++;
	}
	printf(" : %d\n", i + 1);
	return (i);
}
