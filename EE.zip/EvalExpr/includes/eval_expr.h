/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   eval_expr.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cdenis <cdenis@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/08/30 01:37:40 by cdenis            #+#    #+#             */
/*   Updated: 2013/08/30 02:59:59 by cdenis           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef EVAL_EXPR_H
# define EVAL_EXPR_H

#include <unistd.h>
#include <stdio.h>

void	ft_putstr(char *str);
int		ft_next_nbr(char *str);
int		ft_strlgt(char *str);

#endif /* EVAL_EXPR_H*/
